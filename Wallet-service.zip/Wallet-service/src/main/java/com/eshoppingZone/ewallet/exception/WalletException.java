package com.eshoppingZone.ewallet.exception;

public class WalletException extends RuntimeException {
    public WalletException(String message) {
        super(message);
    }
}
