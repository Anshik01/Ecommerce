package com.eshoppingZone.ewallet.exception;

public class InsufficientBalanceExcep extends RuntimeException {
    public InsufficientBalanceExcep(String message) {
        super(message);
    }
}
